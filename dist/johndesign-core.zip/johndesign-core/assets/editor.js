(function(wp){
'use strict';
const el=wp.element.createElement;
const Fragment=wp.element.Fragment;
const {registerBlockType}=wp.blocks;
const {InspectorControls,MediaUpload,MediaUploadCheck,useBlockProps}=wp.blockEditor;
const {PanelBody,TextControl,TextareaControl,Button,BaseControl}=wp.components;
const {select,dispatch,subscribe}=wp.data;
const ServerSideRender=wp.serverSideRender||wp.components.ServerSideRender;

function cleanLabel(f){
  let l=(f.label||'').trim();
  if(/^Titre H1/.test(l)) return 'Titre principal';
  if(/^Titre H2/.test(l)) return 'Titre de section';
  if(/^Titre H3/.test(l)) return 'Sous-titre';
  if(/^Image ·/.test(l)) return l.replace(/^Image ·\s*/, 'Image · ');
  if(/^Libellé \/ lien/.test(l)) {
    const p=l.split('·').map(s=>s.trim()).filter(Boolean);
    return p.length ? 'Lien / bouton · '+p[p.length-1].replace(/https?:\/\/\S+/,'URL') : 'Lien / bouton';
  }
  if(l.includes('jd-eyebrow')) return 'Surtitre';
  if(l.includes('jd-lead')) return 'Texte d’introduction';
  if(l.includes('jd-caption')) return 'Légende';
  if(l.includes('jd-location')) return 'Localisation';
  if(l.includes('jd-step-number')) return 'Numéro d’étape';
  if(l.includes('jd-review-quote')) return 'Avis';
  if(l.includes('jd-review-person')) return 'Auteur de l’avis';
  if(l.includes('jd-site-url')) return 'Adresse du site';
  const parts=l.split('·').map(s=>s.trim()).filter(Boolean);
  if(parts.length>=2){
    const last=parts[parts.length-1];
    if(last.length>3 && !/^jd-/.test(last)) return last.length>70?last.slice(0,67)+'…':last;
  }
  return l||'Contenu';
}
function stripForInput(v){return String(v||'').replace(/<br\s*\/?\s*>/gi,'\n').replace(/<[^>]+>/g,'').replace(/&amp;/g,'&');}
function isShortRich(f,val){
  const label=f.label||'';
  if(/Titre H[123]|jd-eyebrow|jd-step-number|Libellé \/ lien|jd-location/.test(label)) return true;
  return stripForInput(val).length < 90 && !String(val).includes('<a ');
}
function setEditorManagedClass(){
  try{
    const content=(select('core/editor')&&select('core/editor').getEditedPostContent())||'';
    const managed=content.indexOf('wp:johndesign/section')!==-1;
    document.body.classList.toggle('jd-managed-page-editor',managed);
  }catch(e){}
}
wp.domReady(function(){
  setEditorManagedClass();
  let last='';
  subscribe(function(){
    let c='';try{c=(select('core/editor')&&select('core/editor').getEditedPostContent())||'';}catch(e){}
    if(c!==last){last=c;setEditorManagedClass();}
  });
});

registerBlockType('johndesign/section',{
 title:'Module John Design',icon:'layout',category:'design',
 attributes:{sectionId:{type:'string',default:''},fields:{type:'object',default:{}}},supports:{html:false},
 edit:function(props){
   const a=props.attributes;const def=(window.JD_SECTIONS||{})[a.sectionId];
   const blockProps=useBlockProps({className:'jd-module-editor-shell'});
   if(!def)return el('div',blockProps,el('div',{className:'components-placeholder'},'Module John Design non configuré.'));
   const setField=(k,v)=>props.setAttributes({fields:Object.assign({},a.fields||{}, {[k]:v})});
   const current=(f)=> (a.fields&&Object.prototype.hasOwnProperty.call(a.fields,f.key))?a.fields[f.key]:(f.default||'');
   const fields=def.fields||[];
   const groups={text:[],image:[],url:[]};
   fields.forEach(f=>{if(f.type==='image')groups.image.push(f);else if(f.type==='url')groups.url.push(f);else groups.text.push(f);});
   function control(f){
     const val=current(f), label=cleanLabel(f);
     if(f.type==='image') return el('div',{key:f.key,className:'jd-inspector-image'},
       el(BaseControl,{label:label},
         val?el('img',{src:val,className:'jd-inspector-image-preview'}):el('div',{className:'jd-inspector-image-empty'},'Aucune image'),
         el(MediaUploadCheck,{},el(MediaUpload,{onSelect:m=>setField(f.key,m.url),allowedTypes:['image'],render:o=>el(Button,{variant:'secondary',onClick:o.open},val?'Remplacer l’image':'Choisir une image')})),
         val?el(Button,{variant:'tertiary',isDestructive:true,onClick:()=>setField(f.key,'')},'Retirer'):null
       ));
     if(f.type==='url') return el(TextControl,{key:f.key,label:label,type:'url',value:val,onChange:v=>setField(f.key,v),help:'Adresse complète, par exemple https://…'});
     if(isShortRich(f,val)){
       return el(TextControl,{key:f.key,label:label,value:stripForInput(val),onChange:function(v){
         // Keep deliberate line breaks as <br> so the front-end composition is preserved.
         setField(f.key,String(v).replace(/\n/g,'<br/>'));
       }});
     }
     return el(TextareaControl,{key:f.key,label:label,value:stripForInput(val),onChange:function(v){setField(f.key,String(v).replace(/\n/g,'<br/>'))},rows:4});
   }
   const inspector=el(InspectorControls,{},
     groups.text.length?el(PanelBody,{title:'Textes',initialOpen:true},groups.text.map(control)):null,
     groups.image.length?el(PanelBody,{title:'Images',initialOpen:true},groups.image.map(control)):null,
     groups.url.length?el(PanelBody,{title:'Liens',initialOpen:false},groups.url.map(control)):null,
     el(PanelBody,{title:'Informations du module',initialOpen:false},
       el('p',{className:'jd-inspector-help'},'Module : ',el('code',{},a.sectionId)),
       el('p',{className:'jd-inspector-help'},'Vous pouvez déplacer, dupliquer ou supprimer ce module avec la barre d’outils Gutenberg.'))
   );
   function openSettings(){
     try{dispatch('core/edit-post').openGeneralSidebar('edit-post/block');}catch(e){}
   }
   return el(Fragment,{},inspector,
     el('div',blockProps,
       el('div',{className:'jd-module-editor-bar'},
         el('div',{className:'jd-module-editor-id'},el('span',{className:'jd-module-dot'}),el('strong',{},def.title),el('small',{},a.sectionId)),
         el(Button,{variant:'secondary',size:'compact',onClick:openSettings},'Modifier le contenu')
       ),
       el('div',{className:'jd-module-editor-preview'},el(ServerSideRender,{block:'johndesign/section',attributes:a}))
     ));
 },save:function(){return null;}
});
})(window.wp);
