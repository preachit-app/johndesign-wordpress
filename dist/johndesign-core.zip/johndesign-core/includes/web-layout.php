<?php
if (!defined('ABSPATH')) exit;

/**
 * John Design Core 2.16.3 — parcours Site internet + galerie web minimale.
 *
 * Ordre visuel :
 * 1. Web / WordPress
 * 2. Pourquoi le faire
 * 3. Tout ce qu'il faut pour votre site professionnel
 * 4. Pour bien commencer
 * 5. Maintenance & suivi
 * 6. Quelques sites réalisés
 * 7. Vos questions sans détour
 * 8. Une idée en tête
 *
 * Les cartes web ne montrent que la capture : pas de nom, pas d'URL,
 * pas de cartouche ni d'overlay. Toute la capture reste cliquable.
 */

function jd_core_web_layout_plain_2163($value){
    $value=(string)$value;
    $value=str_replace(['<br>','<br/>','<br />'],' ',$value);
    $value=wp_strip_all_tags($value);
    $value=html_entity_decode($value,ENT_QUOTES|ENT_HTML5,'UTF-8');
    $value=preg_replace('/\s+/u',' ',trim($value));
    return mb_strtolower($value);
}

function jd_core_web_layout_block_text_2163($block){
    if(($block['blockName']??'')!=='johndesign/section') return '';

    $parts=[];
    $fields=$block['attrs']['fields']??[];
    if(is_array($fields)){
        foreach($fields as $value){
            if(is_string($value)) $parts[]=$value;
        }
    }

    $sid=$block['attrs']['sectionId']??'';
    $defs=jd_core_sections();
    $def=$defs[$sid]??null;
    if($def && !empty($def['template'])) $parts[]=$def['template'];

    return jd_core_web_layout_plain_2163(implode(' ',$parts));
}

function jd_core_web_layout_type_2163($plain){
    if(!$plain) return '';

    if(
        strpos($plain,'studio en ligne')!==false
        || (
            strpos($plain,'une idée du style')!==false
            && strpos($plain,'explorer la composition')!==false
        )
    ) return 'remove-studio';

    if(
        strpos($plain,'et pour la suite')!==false
        && (
            strpos($plain,'une image cohérente')!==false
            || (
                strpos($plain,'identité visuelle')!==false
                && strpos($plain,'print')!==false
            )
        )
    ) return 'remove-related';

    if(strpos($plain,'pourquoi le faire')!==false) return 'why';

    if(
        strpos($plain,'ce que l’on peut construire')!==false
        || strpos($plain,"ce que l'on peut construire")!==false
        || strpos($plain,'tout ce qu’il faut pour votre site professionnel')!==false
        || strpos($plain,"tout ce qu'il faut pour votre site professionnel")!==false
    ) return 'scope';

    if(strpos($plain,'pour bien commencer')!==false) return 'start';

    if(
        strpos($plain,'vos questions')!==false
        && strpos($plain,'sans détour')!==false
    ) return 'faq';

    if(strpos($plain,'une idée en tête')!==false) return 'cta';

    return '';
}

function jd_core_web_layout_persist_2163(){
    if(get_option('jd_core_web_layout_version')===JD_CORE_VERSION) return;

    $page=get_page_by_path('creation-site-internet');
    if(!($page instanceof WP_Post)){
        update_option('jd_core_web_layout_version',JD_CORE_VERSION,false);
        return;
    }

    $raw=(string)$page->post_content;
    if(!$raw || strpos($raw,'wp:johndesign/section')===false){
        update_option('jd_core_web_layout_version',JD_CORE_VERSION,false);
        return;
    }

    $blocks=parse_blocks($raw);
    $next=[];
    $removed=0;

    foreach($blocks as $block){
        $type=jd_core_web_layout_type_2163(jd_core_web_layout_block_text_2163($block));
        if($type==='remove-studio' || $type==='remove-related'){
            $removed++;
            continue;
        }
        $next[]=$block;
    }

    if($removed){
        wp_update_post([
            'ID'=>$page->ID,
            'post_content'=>wp_slash(serialize_blocks($next)),
        ]);
    }

    update_option('jd_core_web_layout_diag',[
        'removed_blocks'=>$removed,
        'checked_at'=>current_time('mysql'),
    ],false);
    update_option('jd_core_web_layout_version',JD_CORE_VERSION,false);

    wp_cache_flush();
    if(function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
}
add_action('admin_init','jd_core_web_layout_persist_2163',65);
add_action('wp_loaded','jd_core_web_layout_persist_2163',10);

function jd_core_web_layout_add_class_2163($html,$class){
    if(!$html || !$class) return $html;

    if(preg_match('/<section\b[^>]*\bclass=(["\'])(.*?)\1/i',$html)){
        return preg_replace_callback(
            '/<section\b([^>]*?)\bclass=(["\'])(.*?)\2([^>]*)>/i',
            function($m)use($class){
                return '<section'.$m[1].'class='.$m[2].trim($m[3].' '.$class).$m[2].$m[4].'>';
            },
            $html,
            1
        );
    }

    if(preg_match('/<section\b/i',$html)){
        return preg_replace('/<section\b/i','<section class="'.esc_attr($class).'"',$html,1);
    }

    return '<div class="'.esc_attr($class).'">'.$html.'</div>';
}

function jd_core_web_portfolio_items_2163(){
    return [
        ['name'=>'Action Formation Theresa','url'=>'https://actionformationtheresa.fr/'],
        ['name'=>'Cap Multiclôture','url'=>'https://www.capmulticloture.com/'],
        ['name'=>'Église Marseille Kléber','url'=>'https://eglise-marseille-kleber.fr/'],
        [
            'name'=>'Un Max de Vie',
            'url'=>'https://www.unmaxdevie.com/',
            'shot'=>JD_CORE_URL.'assets/portfolio/umdv-site.webp'
        ],
        ['name'=>'Sonicscape Studio','url'=>'https://www.sonicscape-studio.fr/'],
        ['name'=>'ACM Construction Piscine','url'=>'https://www.acm-construction-piscine.fr/'],
        ['name'=>'Bourgaud Services','url'=>'http://bourgaud-services.fr/'],
    ];
}

function jd_core_web_portfolio_shot_2163($item){
    if(!empty($item['shot'])) return (string)$item['shot'];
    $url=(string)($item['url']??'');
    return 'https://s0.wp.com/mshots/v1/'.rawurlencode($url).'?w=1200&h=750';
}

function jd_core_web_portfolio_gallery_2163(){
    $items=jd_core_web_portfolio_items_2163();
    if(!$items) return '';

    $cards='';
    foreach($items as $item){
        $url=(string)$item['url'];
        $shot=jd_core_web_portfolio_shot_2163($item);

        $cards.='<a class="jd-web-portfolio-card" href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer" aria-label="Visiter '.esc_attr($item['name']).'">'
            .'<span class="jd-web-portfolio-visual">'
                .'<img src="'.esc_url($shot).'" alt="Aperçu du site '.esc_attr($item['name']).'" loading="lazy" decoding="async">'
            .'</span>'
        .'</a>';
    }

    return '<section class="jd-web-portfolio-strip" data-jd-horizontal-gallery aria-labelledby="jd-web-portfolio-title">'
        .'<div class="jd-web-portfolio-head">'
            .'<div>'
                .'<p class="jd-eyebrow">QUELQUES SITES RÉALISÉS</p>'
                .'<h2 id="jd-web-portfolio-title">Des sites en ligne,<br>à découvrir.</h2>'
            .'</div>'
            .'<div class="jd-horizontal-gallery-controls" aria-label="Navigation de la galerie">'
                .'<button type="button" class="jd-horizontal-gallery-nav" data-jd-gallery-prev aria-label="Site précédent">←</button>'
                .'<button type="button" class="jd-horizontal-gallery-nav" data-jd-gallery-next aria-label="Site suivant">→</button>'
            .'</div>'
        .'</div>'
        .'<div class="jd-web-portfolio-track" data-jd-gallery-track>'
            .$cards
        .'</div>'
    .'</section>';
}



/**
 * John Design Core 2.16.25 — tarifs Site internet.
 * Une grille commerciale lisible, avec le référencement expliqué sans jargon
 * et un détail dépliable pour l'hébergement, le suivi et l'abonnement.
 */
function jd_core_web_pricing_arrow_21625(){
    return '<span class="jd-cta-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M7 17L17 7"></path><path d="M9 7H17V15"></path></svg></span>';
}

function jd_core_web_pricing_21625(){
    $plans=[
        [
            'class'=>'',
            'label'=>'ESSENTIEL',
            'title'=>'Pour démarrer.',
            'price'=>'990 €',
            'intro'=>'Un site simple et professionnel pour présenter votre activité et permettre à vos clients de vous contacter.',
            'project'=>'Site Essentiel - à partir de 990 €',
            'items'=>[
                ['label'=>'Site one-page','help'=>'Une page claire avec les sections essentielles.'],
                ['label'=>'WordPress + Divi','help'=>'Un site que vous pourrez faire évoluer.'],
                ['label'=>'Adapté au mobile','help'=>'Ordinateur, tablette et téléphone.'],
                ['label'=>'Formulaire de contact','help'=>'Pour recevoir directement les demandes.'],
                ['label'=>'Référencement Google de base','help'=>'Titres, descriptions et réglages essentiels pour aider Google à comprendre votre site.'],
                ['label'=>'Mise en ligne','help'=>'Je m’occupe de la partie technique jusqu’au lancement.'],
            ],
        ],
        [
            'class'=>' is-featured',
            'label'=>'VITRINE',
            'badge'=>'LE PLUS CHOISI',
            'title'=>'Pour présenter votre entreprise.',
            'price'=>'1 490 €',
            'intro'=>'Le format idéal pour une entreprise qui veut expliquer ses services, rassurer et générer des demandes.',
            'project'=>'Site Vitrine - à partir de 1 490 €',
            'items'=>[
                ['label'=>'Jusqu’à 5 pages','help'=>'Par exemple : accueil, services, à propos, réalisations et contact.'],
                ['label'=>'WordPress + Divi','help'=>'Une base professionnelle et évolutive.'],
                ['label'=>'Adapté au mobile','help'=>'Une expérience propre sur tous les écrans.'],
                ['label'=>'Formulaire de contact','help'=>'Avec un parcours pensé pour faciliter les demandes.'],
                ['label'=>'Référencement Google de base','help'=>'Structure, titres et descriptions préparés pour que Google comprenne votre activité.'],
                ['label'=>'Suivi des visites','help'=>'Connexion aux outils Google pour mesurer les visites et les contacts.'],
            ],
        ],
        [
            'class'=>'',
            'label'=>'VITRINE +',
            'title'=>'Pour aller plus loin.',
            'price'=>'1 990 €',
            'intro'=>'Pour une activité qui a davantage de contenus, de services ou qui souhaite travailler plus sérieusement sa visibilité.',
            'project'=>'Site Vitrine Plus - à partir de 1 990 €',
            'items'=>[
                ['label'=>'Jusqu’à 8 à 10 pages','help'=>'Pour présenter plusieurs services ou secteurs d’activité.'],
                ['label'=>'Blog ou réalisations','help'=>'Une partie du site que vous pourrez enrichir dans le temps.'],
                ['label'=>'Référencement local renforcé','help'=>'Pages, titres et structure pensés pour mieux expliquer à Google votre activité et votre zone.'],
                ['label'=>'Suivi des visites','help'=>'Mesure des visites et des demandes depuis Google.'],
                ['label'=>'Accompagnement renforcé','help'=>'Plus de contenu à organiser et à intégrer.'],
                ['label'=>'Mise en ligne & prise en main','help'=>'Le site est livré prêt à utiliser.'],
            ],
        ],
    ];

    $cards='';
    foreach($plans as $plan){
        $items='';
        foreach($plan['items'] as $item){
            $items.='<li>'
                .'<span class="jd-web-pricing__check" aria-hidden="true">✓</span>'
                .'<span><strong>'.esc_html($item['label']).'</strong><small>'.esc_html($item['help']).'</small></span>'
            .'</li>';
        }

        $badge=!empty($plan['badge'])
            ?'<span class="jd-web-pricing__badge">'.esc_html($plan['badge']).'</span>'
            :'';

        $contact=add_query_arg('project',$plan['project'],home_url('/contact/'));

        $cards.='<article class="jd-web-pricing__card'.esc_attr($plan['class']).'">'
            .'<div class="jd-web-pricing__card-top">'
                .'<div><p class="jd-web-pricing__label">'.esc_html($plan['label']).'</p>'.$badge.'</div>'
                .'<h3>'.esc_html($plan['title']).'</h3>'
                .'<p class="jd-web-pricing__price"><span>À partir de</span><strong>'.esc_html($plan['price']).'</strong></p>'
                .'<p class="jd-web-pricing__intro">'.esc_html($plan['intro']).'</p>'
            .'</div>'
            .'<ul class="jd-web-pricing__features">'.$items.'</ul>'
            .'<a class="jd-web-pricing__cta" href="'.esc_url($contact).'">Parler de cette formule '.jd_core_web_pricing_arrow_21625().'</a>'
        .'</article>';
    }

    $subscription=add_query_arg('project','Site vitrine en abonnement - 89 €/mois',home_url('/contact/'));

    return '<section class="jd-web-pricing" id="tarifs" aria-labelledby="jd-web-pricing-title">'
        .'<div class="jd-web-pricing__inner">'
            .'<header class="jd-web-pricing__head">'
                .'<div>'
                    .'<p class="jd-eyebrow">TARIFS SITE INTERNET</p>'
                    .'<h2 id="jd-web-pricing-title">Des prix clairs.<br>Pas de jargon.</h2>'
                .'</div>'
                .'<p>Chaque projet reste adapté à votre activité, mais vous savez dès le départ dans quel ordre de prix vous vous situez.</p>'
            .'</header>'
            .'<div class="jd-web-pricing__grid">'.$cards.'</div>'
            .'<details class="jd-web-pricing__more">'
                .'<summary>'
                    .'<span><strong>En savoir plus sur les tarifs</strong><small>Référencement, hébergement, maintenance et paiement mensuel.</small></span>'
                    .'<span class="jd-web-pricing__plus" aria-hidden="true">+</span>'
                .'</summary>'
                .'<div class="jd-web-pricing__more-body">'
                    .'<div class="jd-web-pricing__explain">'
                        .'<span class="jd-web-pricing__number">01</span>'
                        .'<h3>Le « référencement Google », concrètement ?</h3>'
                        .'<p>On parle aussi de SEO ou de référencement naturel. En clair : je prépare la structure du site, les titres, les descriptions et les principaux réglages pour aider Google à comprendre qui vous êtes, ce que vous proposez et où vous travaillez.</p>'
                        .'<p class="jd-web-pricing__fine">Cela prépare de bonnes bases, mais ne promet pas une première place sur Google. Un accompagnement de référencement régulier peut faire l’objet d’un devis séparé.</p>'
                    .'</div>'
                    .'<div class="jd-web-pricing__explain">'
                        .'<span class="jd-web-pricing__number">02</span>'
                        .'<h3>Et après la mise en ligne ?</h3>'
                        .'<div class="jd-web-pricing__mini-prices">'
                            .'<div><strong>12 € / mois</strong><span>Hébergement géré</span><small>Hébergement, SSL et gestion technique du compte.</small></div>'
                            .'<div><strong>39 € / mois</strong><span>Formule Sérénité</span><small>Hébergement, mises à jour, sauvegardes, surveillance et suivi courant.</small></div>'
                        .'</div>'
                    .'</div>'
                    .'<div class="jd-web-pricing__explain jd-web-pricing__subscription">'
                        .'<span class="jd-web-pricing__number">03</span>'
                        .'<h3>Vous préférez étaler l’investissement ?</h3>'
                        .'<p class="jd-web-pricing__subscription-price"><strong>290 €</strong> à la mise en service <span>+</span> <strong>89 € / mois</strong> pendant 24 mois.</p>'
                        .'<p>Cette formule permet de démarrer avec un site vitrine, l’hébergement et la maintenance inclus, sans régler toute la création en une seule fois. Au terme des 24 mois, le site vous appartient et le suivi devient facultatif.</p>'
                        .'<a href="'.esc_url($subscription).'" class="jd-web-pricing__text-link">Découvrir cette formule '.jd_core_web_pricing_arrow_21625().'</a>'
                    .'</div>'
                    .'<div class="jd-web-pricing__note">'
                        .'<strong>Ce qui peut faire évoluer le prix</strong>'
                        .'<p>Boutique en ligne, réservation, espace privé, plusieurs langues, rédaction importante, fonctionnalités spécifiques ou quantité de contenu supérieure au forfait choisi. Dans tous les cas, le périmètre et le prix sont validés avant de commencer.</p>'
                    .'</div>'
                .'</div>'
            .'</details>'
            .'<p class="jd-web-pricing__legal">Tarifs indicatifs « à partir de ». Un devis précise toujours le contenu exact du projet avant démarrage.</p>'
        .'</div>'
    .'</section>';
}

function jd_core_web_layout_render_2163($block_content,$block){
    if(!is_page('creation-site-internet')) return $block_content;
    if(($block['blockName']??'')!=='johndesign/section') return $block_content;

    $plain=jd_core_web_layout_plain_2163($block_content);
    $type=jd_core_web_layout_type_2163($plain);

    if($type==='remove-studio' || $type==='remove-related') return '';

    if($type==='why'){
        return jd_core_web_layout_add_class_2163(
            $block_content,
            'jd-web-flow-section jd-web-flow-soft'
        );
    }

    if($type==='scope'){
        return jd_core_web_layout_add_class_2163(
            $block_content,
            'jd-web-flow-section jd-web-flow-card jd-web-flow-scope'
        ).jd_core_web_pricing_21625();
    }

    if($type==='start'){
        return jd_core_web_layout_add_class_2163(
            $block_content,
            'jd-web-flow-section jd-web-flow-pink'
        );
    }

    if($type==='faq'){
        $faq=jd_core_web_layout_add_class_2163(
            $block_content,
            'jd-web-flow-section jd-web-flow-card jd-web-flow-faq'
        );

        return '<div class="jd-web-maintenance-injected jd-web-maintenance-in-flow">'
            .jd_core_web_maintenance_2151()
            .'</div>'
            .jd_core_web_portfolio_gallery_2163()
            .$faq;
    }

    if($type==='cta'){
        return jd_core_web_layout_add_class_2163(
            $block_content,
            'jd-web-flow-section jd-web-flow-soft jd-web-flow-cta'
        );
    }

    return $block_content;
}
add_filter('render_block','jd_core_web_layout_render_2163',70,2);
